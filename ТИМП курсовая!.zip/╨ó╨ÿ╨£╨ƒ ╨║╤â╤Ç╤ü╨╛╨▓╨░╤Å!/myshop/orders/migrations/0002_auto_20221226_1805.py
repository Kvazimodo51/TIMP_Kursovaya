# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('orders', '0001_initial'),
    ]

    operations = [
        migrations.RenameField(
            model_name='order',
            old_name='address',
            new_name='Адрес',
        ),
        migrations.RenameField(
            model_name='order',
            old_name='city',
            new_name='Город',
        ),
        migrations.RenameField(
            model_name='order',
            old_name='first_name',
            new_name='Имя',
        ),
        migrations.RenameField(
            model_name='order',
            old_name='email',
            new_name='Почта',
        ),
        migrations.RenameField(
            model_name='order',
            old_name='postal_code',
            new_name='Почтовый_индекс',
        ),
        migrations.RenameField(
            model_name='order',
            old_name='last_name',
            new_name='Фамилия',
        ),
    ]
