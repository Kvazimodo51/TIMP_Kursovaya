from celery import task
from django.core.mail import send_mail
from .models import Order
#Задача для отправки уведомления по электронной почте при успешном создании заказа.
@task
def order_created(order_id):
    order = Order.objects.get(id=order_id)
    subject = 'Заказ номер. {}'.format(order_id) 
    message = 'Dear {},\n\nВы успешно оформили заказ.\ Номер заказа: {}.'.format(order.Имя, order.id)
    mail_sent = send_mail(subject, message,'admin@myshop.com',[order.Почта])
    return mail_sent